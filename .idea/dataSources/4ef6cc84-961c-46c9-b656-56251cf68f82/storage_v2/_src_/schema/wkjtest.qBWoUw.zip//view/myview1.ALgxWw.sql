create definer = root@localhost view myview1 as
select `wkjtest`.`emp_bak`.`EMPNO` AS `empno`,
       `wkjtest`.`emp_bak`.`ENAME` AS `ename`,
       `wkjtest`.`emp_bak`.`SAL`   AS `sal`
from `wkjtest`.`emp_bak`;

